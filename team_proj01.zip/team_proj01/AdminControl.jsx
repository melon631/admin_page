import './AdminMain.css';

export default function AdminControl({AddSchedule}){

  return(
    <div>
      <div className="admin-header">
        <div className="search-group">
          <input type="text" placeholder="과목명 또는 강의실 검색" className="search-input" />
          <button className="search-btn">검색</button>
        </div>
        <div className="action-group">
          <button className="reg-btn" onClick={AddSchedule}>등록</button>
          <button className="del-btn">삭제</button>
        </div>
      </div>
    </div>
  );
}