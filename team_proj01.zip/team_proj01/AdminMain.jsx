import React, { useState } from 'react';
import AdminControl from './AdminControl';
import AdminTable from './AdminTable';
import AdminModal from './AdminModal';
import './AdminMain.css';

const dummy_ad = [
  {
    id: '1',
    code: '11111',
    name: '리액트 프로그래밍',
    section: '01',
    schedules: [
      { "day": "월", "time": "01:00 ~ 02:15", "room": "공1201" },
      { "day": "수", "time": "03:00 ~ 04:15", "room": "공1201" }
    ]
  },
  {
    id: '2',
    code: '11112',
    name: '운영체제',
    section: '02',
    day: '화',
    time: '02:30 ~ 03:45',
    room: '공1105'
  }
]
export default function AdminMain() {
  const [text, setText] = useState("");
  const [schedule, setSchedule] = useState(dummy_ad);   //
  const [isModalOpen, setIsModalOpen] = useState(false);  // 팝업뜨게
  const timeTable = {
    id: Date.now(),
    code: '',
    name: '',
    section: '',
    schedules: [{
      day: '',
      time: '',
      room: '',
    }]
  }
  function handleText(e) {
    setText(e.target.value);
  }
  //상단 등록 버튼 누름 창이 뜸
  function AddSchedule() {
    setIsModalOpen(true);
  }
  function handleSave(newData) {
    if (newData.code === "" || newData.name === "" || newData.section === "") {
      alert("빈칸을 모두 채워주세요!");
      return;
    }
    setSchedule([...schedule, newData]);
    setIsModalOpen(false);
    alert('등록했습니다.');
  }
  return (
    <div className="admin-main">
      <div>{/* 상단 컨트롤 영역 */}
        <AdminControl handleText={handleText} AddSchedule={AddSchedule} />
      </div>
      {/* 하단 리스트 영역: 엑셀 형식의 테이블 */}
      <div className="admin-list-container">
        <AdminTable dummy_ad={dummy_ad} schedule={schedule} />
      </div>
      <div>
        {isModalOpen && (
          <AdminModal
            onClose={() => setIsModalOpen(false)}
            handleSave={handleSave}
          />
        )}
      </div>
    </div>
  );
}