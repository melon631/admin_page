import React, { useState } from 'react';
import './Reservation.css';
import LectureMain from './LectureMain';
import LoungeMain from './LoungeMain';

export default function Reservation() {
  const [mode, setMode] = useState('lecture'); // 'lecture' 또는 'lounge'

  return (
    <div className="reservation-wrapper">
      <div className="admin-header">
        <h2 className="admin-title">{mode === 'lecture' ? '강의실' : '라운지'}</h2>
        
        {/* 슬라이드 토글 버튼 */}
        <div className="mode-toggle-container" onClick={() => setMode(mode === 'lecture' ? 'lounge' : 'lecture')}>
          <div className={`toggle-background ${mode}`}></div>
          <button 
            className={`toggle-btn ${mode === 'lecture' ? 'active' : ''}`}
            type="button"
          >
            강의실
          </button>
          <button 
            className={`toggle-btn ${mode === 'lounge' ? 'active' : ''}`}
            type="button"
          >
            라운지
          </button>
        </div>
      </div>

      {/* 모드에 따라 컴포넌트 교체 */}
      <div className="content-area">
        {mode === 'lecture' ? <LectureMain /> : <LoungeMain />}
      </div>
    </div>
  );
}