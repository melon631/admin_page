

const dummy2 = [
  { num: 1,
    date: '2025/05/10', 
    day: '월', 
    time: '1시 ~ 2시', 
    lecture: '공1201',
    allow: '0'
  },
  { num: 2, 
    date: '2025/05/11', 
    day: '수', 
    time: '1시 ~ 2시', 
    lecture: '공1202',
    allow: '0'
  },
  { num: 3, 
    date: '2025/05/11', 
    day: '수', 
    time: '1시 ~ 2시', 
    lecture: '공1202',
    allow: '1' 
  }
];
{/*
- true flase로 뒀을 때 flase면 대기상태 true면 처리완료인데 그러면 처리완료에서 승인이랑 거절 구분 힘듦 
그래서 0,1,2로 두고 0이 대기, 1이 승인, 2가 거절 상태를 만들어서 관리하기
그리고 처리완료에 갔을 때 당연히 승인과 거절 구분되어야 하고, 처리완료에만 삭제 버튼이 생기게 만들기
삭제 버튼은 당연히 체크 된거만 삭제 , 일괄 체크/해제, 처리한 시간도 나오게 하기
 */}

export default function LoungeMain() {
  return (
    <div className="admin-container">
      <div className="tab-wrapper">
        <button className="tab-item active">대기중</button>
        <button className="tab-item">처리완료</button>
      </div>
      <div className='reservation-row'>
        <div>번호</div>
        <div>날짜</div>
        <div>요일</div>
        <div>시간</div>
        <div>장소</div>
      </div>
      {dummy2.map((item) => (
        <div className="reservation-row">
          <span className="col-num">{item.num}</span>     {/* classname만 선언 num ~ room */}
          <span className="col-date">{item.date}</span>
          <span className="col-day">{item.day}요일</span>
          <span className="col-time">{item.time}</span>
          <span className="col-room">{item.lecture}</span>
          <div>
            <button className="accept-btn">수락</button>
            <button className="reject-btn">거절</button>
          </div>

        </div>
      ))}
    </div>
  );
}
