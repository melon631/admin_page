import { useState } from "react";
import './Modal.css'

export default function AdminModal({ onClose, handleSave }) {
  // 여기서 인풋 상태들을 관리 (과목코드, 과목명 등)
  const [formData, setFormData] = useState({
    id: Date.now(),
    code: '',
    name: '',
    section: '',
    schedules: '',
    day1: '', day2: '',
    time1: '', time2: '',
    room1: '', room2: '',
  });
  function Accept() {
    const schedules = [
      { day: formData.day1, time: formData.time1, room: formData.room1 }
    ];
    if (formData.day2 && formData.day2.trim() !== "") {
      schedules.push({
        day: formData.day2,
        time: formData.time2,
        room: formData.room2
      });
    }
    const finalData = {
      id: Date.now(),
      code: formData.code,
      name: formData.name,
      section: formData.section,
      schedules: schedules
    };
    handleSave(finalData);
  }

  function handleChange(e) {
    const { name, value } = e.target;
    setFormData({ ...formData, [name]: value });
  };

  return (
    <div className="modal-overlay"> {/* 화면 전체를 어둡게 덮는 배경 */}
      <div className="modal-content"> {/* 중앙의 흰색 상자 */}
        <h2>새 강의 등록</h2>
        <div className="input-group">
          <input type="text" name="code" placeholder="과목코드" onChange={handleChange} />
          <input type="text" name="name" placeholder="과목명" onChange={handleChange} />
          <input type="text" name="section" placeholder="분반" onChange={handleChange} />

          <div className="modal-text">1개만 작성해도 된다면 xx2는 빈칸으로 작성</div>

          <div className="input-row">
            <input type="text" name="day1" placeholder="요일1" onChange={handleChange} />
            <input type="text" name="day2" placeholder="요일2" onChange={handleChange} />
          </div>

          <div className="input-row">
            <input type="text" name="time1" placeholder="시간1 (00:00 ~ 00:00)" onChange={handleChange} />
            <input type="text" name="time2" placeholder="시간2 (00:00 ~ 00:00)" onChange={handleChange} />
          </div>

          <div className="input-row">
            <input type="text" name="room1" placeholder="강의실1" onChange={handleChange} />
            <input type="text" name="room2" placeholder="강의실2" onChange={handleChange} />
          </div>
        </div>
        <div className="modal-btns">
          <button className="save-btn" onClick={Accept}>등록</button>
          <button className="close-btn" onClick={onClose}>취소</button>
        </div>
      </div>
    </div>
  );
}