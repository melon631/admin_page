

const dummy1 = [
  { num: 1,
    date: '2025/05/10', 
    day: '월', 
    time: '1시 ~ 2시', 
    desknum: '10',
    
  },
  { num: 2, 
    date: '2025/05/11', 
    day: '수', 
    time: '1시 ~ 2시', 
    desknum: '2', 
  }
];

export default function LectureMain() {
  return (
    <div className="admin-container">
      <div className="tab-wrapper">
        <button className="tab-item active">대기중</button>
        <button className="tab-item">처리완료</button>
      </div>
      <div className='reservation-row'>
        <div>번호</div>
        <div>날짜</div>
        <div>요일</div>
        <div>시간</div>
        <div>책상번호</div>
      </div>
      {dummy1.map((item) => (
        <div className="reservation-row">
          <span className="col-num">{item.num}</span>     {/* classname만 선언 num ~ room */}
          <span className="col-date">{item.date}</span>
          <span className="col-day">{item.day}요일</span>
          <span className="col-time">{item.time}</span>
          <span className="col-room">{item.desknum}</span>
          <div>
            <button className="accept-btn">수락</button>
            <button className="reject-btn">거절</button>
          </div>

        </div>
      ))}
    </div>
  );
}