import './AdminMain.css'

export default function AdminTable({dummy_ad, schedule}) {

  return (
    <div>
      <table className="admin-table">
        <thead>
          <tr>
            <th>선택</th>
            <th>과목코드</th>
            <th>과목명</th>
            <th>분반</th>
            <th>요일/시간</th>
            <th>강의실</th>
            <th>관리</th>
          </tr>
        </thead>
        <tbody>
          {dummy_ad.map((sch) => (
            <tr key={sch.code}>
              <td><input type="checkbox" /></td>
              <td>{sch.code}</td>
              <td>{sch.name}</td>
              <td>{sch.section}</td>

              {/* 요일/시간 칸 수정 
                      ep이터 있음 나오고 비어있으면 '-' 이걸로 나오게 만든 것*/}
              <td>
                {sch.schedules ? (
                  sch.schedules.map((s, idx) => (
                    <div key={idx}>{s.day} ({s.time})</div>
                  ))
                ) : (
                  sch.day ? `${sch.day} (${sch.time})` : '-'
                )}
              </td>

              {/* 강의실 칸 수정 */}
              <td>
                {sch.schedules ? (
                  // 배열 안의 강의실들을 중복 없이 혹은 나열해서 표시
                  sch.schedules.map((s, idx) => (
                    <div key={idx}>{s.room}</div>
                  ))
                ) : (
                  sch.room || '-'
                )}
              </td>

              <td>
                <button className="edit-btn">수정</button>
                <button className='del-btn'>삭제</button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}